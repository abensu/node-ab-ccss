﻿var ccss = require("node-ab-ccss");

ccss.run(__dirname + "/../", "/node-abc/node-ab-ccss-files.txt", "text");